﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Configuration;

namespace WindowsFormsApp1
{
    public partial class LoginForm : Form
    {
        public LoginForm()
        {
            InitializeComponent();
            
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            
        }

        private void Login_Click(object sender, EventArgs e)
        {           
            if (isValid())
            {
                using (SqlConnection conn = new SqlConnection(Connection.ConnString))
                {
                    string query = "Select * from Login where username ='" + Username.Text.Trim() + "' and password = '" + Password.Text.Trim() + "'";
                    SqlDataAdapter sda = new SqlDataAdapter(query, conn);
                    DataTable dta = new DataTable();
                    sda.Fill(dta);
                   
                    if (dta.Rows.Count == 1)
                    {
                        //MessageBox.Show(dta.Rows.Count.ToString());
                        MainForm form1 = new MainForm();
                        this.Hide();
                        form1.Show();
                    }
                    else
                    {
                        MessageBox.Show("Username and password not valid", "Error");
                    }
                }
            }
        }


        private bool isValid()
        {
            if (Username.Text.TrimStart() == string.Empty || Password.Text.TrimStart() == string.Empty)
            {
                MessageBox.Show("Enter valid username and password empty", "Error");
                return false;
            }
            return true;
        }

    }
}
