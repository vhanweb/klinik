Cracked Dlls of Bunifu C# Framework - WinForms (NuGet Version: 4.1.1)


How to use?
1. Create a folder where u want to store the DLLs.
2. Open Visual Studio IDE and right click on the toolbox, and click 'Choose Items'
3. When its done loading click browse, And select all the bunifu DLLs
4. Use Bunifu for free!

!!!! 
Sometimes u get an error related to the licensing when running compiler.
To fix this remove the license file from the project.
!!!!
